import {Link} from 'react-router-dom'
import './style.css';
function Header(){
    return(
        <header>
            <div id = 'nomeEmpresa'>PeladoBank</div>
            <div>
                <Link to = "/">Home</Link>
                <Link to = "/cadcli">Cadatrar Cliente</Link>
                <Link to = "/financ">Simular Financiamento</Link>
                <Link to = "/conta">Conta Corrente</Link>
                <Link to = "/sobre">Sobre Nós</Link>
            </div>
            
        </header>
    )
}
export default Header;