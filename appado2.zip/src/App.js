/** - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
2 * SENAC - TADS - Programacao Web *
3 * ADO #02 Trabalhando As Rotas e LINKS *
4 * - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
5 * Nome : Gabriel de Melo Silva*
6 * - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
import RouterApp from "./routes";

function App() {
  return (
  <RouterApp/>    
  );
}

export default App;
