function Cadastro() {
    return(
        <div>
            <h1>Pagina Cadastro</h1>
        </div>
    )
}
export default Cadastro;