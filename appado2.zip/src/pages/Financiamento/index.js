function Financiamento() {
    return(
        <div>
            <h1>Pagina Financiamento</h1>
        </div>
    )
}
export default Financiamento;