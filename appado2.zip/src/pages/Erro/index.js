function Erro() {
    return(
        <div>
            <h1>404</h1>
            <h2>página errada bobão</h2>
        </div>
    )
}
export default Erro;