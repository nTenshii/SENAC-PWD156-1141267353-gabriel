import {BrowserRouter, Routes, Route} from "react-router-dom";
import Cadastro from "./pages/Cadastro";
import Conta from "./pages/Conta";
import Erro from "./pages/Erro";
import Financiamento from "./pages/Financiamento";
import Home from "./pages/Home";
import Sobrenos from "./pages/Sobrenos";
import Header from "./components/Header";

function RouterApp() {
    return(
        <BrowserRouter>
        <Header/>
            <Routes>
                    <Route path ='/' element={<Home/>}/>
                    <Route path ='/cadcli' element={<Cadastro/>}/>
                    <Route path ='/financ' element={<Financiamento/>}/>
                    <Route path ='/conta' element={<Conta/>}/>
                    <Route path ='/sobre' element={<Sobrenos/>}/>
                    <Route path ='*' element={<Erro/>}/>
            </Routes>
        </BrowserRouter>

    )
}
export default RouterApp;